# RicozTrigger — Basic Frontend Prototype

This is an initial static frontend prototype inspired by the supplied design.

## Included
- `index.html` — page structure and content
- `style.css` — responsive styling
- No Node.js, npm, backend, database, or API required

## Run it
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Double-click `index.html` to open it in a browser, or use the VS Code Live Server extension.

This is intentionally a basic first phase. Backend services, authentication, trigger configuration, event-source connections, and real workflow execution are not implemented yet.
