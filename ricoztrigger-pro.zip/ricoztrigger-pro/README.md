# RicozTrigger
Enterprise event-driven automation platform.
**Event → Ingestion API → Trigger Engine → Condition Evaluation → Workflow → Action → Execution Log**

Stack: Next.js 14 · Node.js + Express · MongoDB (Mongoose)

## Run (Node 18+ and MongoDB required)
```bash
docker compose up -d        # MongoDB (skip if you already run MongoDB / Atlas)
npm run install:all         # installs root, backend and frontend deps
npm run dev                 # API :5000 + web :3000
```
Edit `backend/.env` first (set `JWT_SECRET`). Open http://localhost:3000, register (first user = admin), click **Load demo data** on the Dashboard, then send the default event on the **Events** page.

Run separately: `cd backend && npm install && npm start` / `cd frontend && npm install && npm run dev`.

## API (JWT Bearer except auth)
`POST /api/auth/register|login` · `GET /api/auth/me` · `GET|POST /api/workflows` · `DELETE /api/workflows/:id` · `GET|POST /api/triggers` · `PATCH /api/triggers/:id/toggle` · `DELETE /api/triggers/:id` · `POST|GET /api/events` · `GET /api/executions` · `GET /api/stats` · `POST /api/demo`

## Security
bcrypt, JWT, zod validation, helmet, CORS, auth rate-limit, per-user data isolation (admin sees all), webhook SSRF guard for local/private hosts.
