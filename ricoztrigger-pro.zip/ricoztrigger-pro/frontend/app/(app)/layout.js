'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { api } from '../../lib/api';

const links = [['/dashboard', 'Dashboard'], ['/triggers', 'Triggers'], ['/workflows', 'Workflows'], ['/events', 'Events'], ['/executions', 'Executions']];

export default function AppLayout({ children }) {
  const router = useRouter();
  const path = usePathname();
  const [user, setUser] = useState(null);

  useEffect(() => {
    api('/auth/me').then((d) => setUser(d.user)).catch((e) => {
      if (e.status === 401 || !localStorage.getItem('rt_token')) { localStorage.removeItem('rt_token'); router.replace('/login'); }
      else setUser(false);
    });
  }, [router]);

  if (user === null) return <p className="loading">Loading…</p>;
  if (user === false) return <p className="loading err">Cannot reach the API. Start the backend and refresh.</p>;
  const logout = () => { localStorage.removeItem('rt_token'); router.replace('/login'); };

  return (
    <div className="shell">
      <aside className="side">
        <Link href="/" className="logo light">Ricoz<span>Trigger</span></Link>
        <nav>{links.map(([href, label]) => <Link key={href} href={href} className={path.startsWith(href) ? 'active' : ''}>{label}</Link>)}</nav>
        <div className="user"><b>{user.name}</b><small>{user.email} · {user.role}</small><button className="btn ghost sm" onClick={logout}>Log out</button></div>
      </aside>
      <main className="content">{children}</main>
    </div>
  );
}
