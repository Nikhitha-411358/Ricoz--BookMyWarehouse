'use client';
import { useEffect, useState } from 'react';
import { api, fmt } from '../../../lib/api';
import { PageHeader, Field, Empty, StatusBadge } from '../../../components/ui';

export default function Events() {
  const [f, setF] = useState({ eventType: 'ORDER_CREATED', source: 'demo' });
  const [payload, setPayload] = useState('{\n  "order_id": "ORD-1001",\n  "amount": 75000,\n  "customer": "Demo Customer"\n}');
  const [events, setEvents] = useState(null);
  const [result, setResult] = useState(null);
  const [err, setErr] = useState('');
  const load = () => api('/events').then((d) => setEvents(d.events)).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, []);

  async function send(e) {
    e.preventDefault(); setErr(''); setResult(null);
    let parsed;
    try { parsed = JSON.parse(payload); } catch { return setErr('Payload must be valid JSON.'); }
    try { setResult(await api('/events', { method: 'POST', body: { ...f, payload: parsed } })); load(); } catch (x) { setErr(x.message); }
  }
  return (
    <>
      <PageHeader title="Events" subtitle="Send a test event and see which triggers fire." />
      <form className="card" onSubmit={send}>
        <div className="row">
          <Field label="Event type" grow={1}><input value={f.eventType} onChange={(e) => setF({ ...f, eventType: e.target.value })} required /></Field>
          <Field label="Source" grow={1}><input value={f.source} onChange={(e) => setF({ ...f, source: e.target.value })} /></Field>
        </div>
        <Field label="Payload (JSON)"><textarea rows={6} value={payload} onChange={(e) => setPayload(e.target.value)} spellCheck={false} /></Field>
        {err && <p className="err">{err}</p>}
        <button className="btn">Send event</button>
      </form>
      {result && (
        <div className="card result">
          <h3>{result.executions.length ? `${result.executions.length} trigger(s) fired` : 'Event processed — no triggers matched'}</h3>
          {result.executions.map((x) => <p key={x._id}><StatusBadge status={x.status} /> <b>{x.triggerName}</b> — {x.message}</p>)}
        </div>
      )}
      <div className="card">
        <h3>Event history</h3>
        {!events ? <p className="mute">Loading…</p> : events.length === 0 ? <Empty>No events yet.</Empty> : (
          <div className="table-wrap"><table><thead><tr><th>Time</th><th>Type</th><th>Source</th><th>Matched</th><th>Payload</th></tr></thead><tbody>
            {events.map((e) => <tr key={e._id}><td>{fmt(e.createdAt)}</td><td>{e.eventType}</td><td>{e.source}</td><td>{e.matched}</td><td><code>{JSON.stringify(e.payload)}</code></td></tr>)}
          </tbody></table></div>
        )}
      </div>
    </>
  );
}
