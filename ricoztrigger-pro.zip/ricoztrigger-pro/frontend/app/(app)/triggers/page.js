'use client';
import { useEffect, useState } from 'react';
import { api } from '../../../lib/api';
import { PageHeader, Field, Empty, Badge } from '../../../components/ui';

const OPS = ['==', '!=', '>', '<', '>=', '<=', 'contains'];
const empty = { name: '', eventType: '', field: '', operator: '>', value: '', workflow: '' };

export default function Triggers() {
  const [list, setList] = useState(null);
  const [workflows, setWorkflows] = useState([]);
  const [f, setF] = useState(empty);
  const [err, setErr] = useState('');
  const load = () => api('/triggers').then((d) => setList(d.triggers)).catch((e) => setErr(e.message));
  useEffect(() => { load(); api('/workflows').then((d) => setWorkflows(d.workflows)).catch(() => {}); }, []);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const act = (p) => p.then(load).catch((x) => setErr(x.message));

  async function create(e) {
    e.preventDefault(); setErr('');
    try { await api('/triggers', { method: 'POST', body: f }); setF(empty); load(); } catch (x) { setErr(x.message); }
  }
  return (
    <>
      <PageHeader title="Triggers" subtitle="Conditions evaluated against every incoming event." />
      <form className="card" onSubmit={create}>
        <h3>New trigger</h3>
        <div className="row">
          <Field label="Name" grow={2}><input value={f.name} onChange={set('name')} required minLength={2} /></Field>
          <Field label="Event type" grow={1}><input value={f.eventType} onChange={set('eventType')} required placeholder="ORDER_CREATED" /></Field>
        </div>
        <div className="row">
          <Field label="Payload field" grow={2}><input value={f.field} onChange={set('field')} required placeholder="amount or order.total" /></Field>
          <Field label="Operator" grow={1}><select value={f.operator} onChange={set('operator')}>{OPS.map((o) => <option key={o}>{o}</option>)}</select></Field>
          <Field label="Value" grow={1}><input value={f.value} onChange={set('value')} required placeholder="50000" /></Field>
          <Field label="Workflow" grow={2}><select value={f.workflow} onChange={set('workflow')}><option value="">— none (record match only) —</option>{workflows.map((w) => <option key={w._id} value={w._id}>{w.name}</option>)}</select></Field>
        </div>
        {err && <p className="err">{err}</p>}
        <button className="btn">Create trigger</button>
      </form>
      <div className="card">
        {!list ? <p className="mute">Loading…</p> : list.length === 0 ? <Empty>No triggers yet.</Empty> : (
          <div className="table-wrap"><table><thead><tr><th>Name</th><th>Event</th><th>Condition</th><th>Workflow</th><th>Runs</th><th>State</th><th /></tr></thead><tbody>
            {list.map((t) => (
              <tr key={t._id}>
                <td><b>{t.name}</b></td><td><Badge kind="matched">{t.eventType}</Badge></td>
                <td><code>{t.field} {t.operator} {t.value}</code></td><td>{t.workflow?.name || '—'}</td><td>{t.runs}</td>
                <td><Badge kind={t.enabled ? 'on' : 'off'}>{t.enabled ? 'Enabled' : 'Disabled'}</Badge></td>
                <td className="row"><button className="btn ghost sm" onClick={() => act(api(`/triggers/${t._id}/toggle`, { method: 'PATCH' }))}>{t.enabled ? 'Disable' : 'Enable'}</button>
                  <button className="btn ghost sm" onClick={() => confirm('Delete this trigger?') && act(api(`/triggers/${t._id}`, { method: 'DELETE' }))}>Delete</button></td>
              </tr>
            ))}
          </tbody></table></div>
        )}
      </div>
    </>
  );
}
