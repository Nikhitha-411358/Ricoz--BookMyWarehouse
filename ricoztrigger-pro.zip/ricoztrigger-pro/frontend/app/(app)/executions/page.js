'use client';
import { useEffect, useState } from 'react';
import { api, fmt } from '../../../lib/api';
import { PageHeader, Empty, StatusBadge } from '../../../components/ui';

export default function Executions() {
  const [rows, setRows] = useState(null);
  const [err, setErr] = useState('');
  const load = () => api('/executions').then((d) => setRows(d.executions)).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, []);
  return (
    <>
      <PageHeader title="Executions" subtitle="Audit log of every trigger run.">
        <button className="btn ghost" onClick={load}>Refresh</button>
      </PageHeader>
      {err && <p className="err">{err}</p>}
      <div className="card">
        {!rows ? <p className="mute">Loading…</p> : rows.length === 0 ? <Empty>No executions yet.</Empty> : (
          <div className="table-wrap"><table><thead><tr><th>Time</th><th>Trigger</th><th>Workflow</th><th>Status</th><th>Result</th><th>Duration</th></tr></thead><tbody>
            {rows.map((r) => <tr key={r._id}><td>{fmt(r.createdAt)}</td><td>{r.triggerName}</td><td>{r.workflowName || '—'}</td><td><StatusBadge status={r.status} /></td><td>{r.message}</td><td>{r.durationMs} ms</td></tr>)}
          </tbody></table></div>
        )}
      </div>
    </>
  );
}
