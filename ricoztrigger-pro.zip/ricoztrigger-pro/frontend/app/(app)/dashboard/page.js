'use client';
import { useEffect, useState } from 'react';
import { api, fmt } from '../../../lib/api';
import { PageHeader, StatusBadge, Empty } from '../../../components/ui';

export default function Dashboard() {
  const [s, setS] = useState(null);
  const [err, setErr] = useState('');
  const load = () => api('/stats').then(setS).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, []);
  const demo = () => api('/demo', { method: 'POST' }).then(load).catch((e) => setErr(e.message));

  const cards = s && [
    ['Active triggers', `${s.activeTriggers} / ${s.triggers}`], ['Workflows', s.workflows], ['Events received', s.events],
    ['Executions', s.executions], ['Failed', s.failed], ['Success rate', s.successRate == null ? '—' : `${s.successRate}%`],
  ];
  return (
    <>
      <PageHeader title="Dashboard" subtitle="Live overview of events, triggers and execution reliability.">
        <button className="btn ghost" onClick={demo}>Load demo data</button>
      </PageHeader>
      {err && <p className="err">{err}</p>}
      {!s ? <p className="mute">Loading…</p> : (
        <>
          <div className="stats">{cards.map(([k, v]) => <div className="card stat" key={k}><span>{k}</span><b>{v}</b></div>)}</div>
          <div className="card">
            <h3>Recent executions</h3>
            {s.recent.length === 0 ? <Empty>No executions yet. Click “Load demo data”, then send an event from the Events page.</Empty> : (
              <div className="table-wrap"><table><thead><tr><th>Time</th><th>Trigger</th><th>Status</th><th>Result</th></tr></thead><tbody>
                {s.recent.map((r) => <tr key={r._id}><td>{fmt(r.createdAt)}</td><td>{r.triggerName}</td><td><StatusBadge status={r.status} /></td><td>{r.message}</td></tr>)}
              </tbody></table></div>
            )}
          </div>
        </>
      )}
    </>
  );
}
