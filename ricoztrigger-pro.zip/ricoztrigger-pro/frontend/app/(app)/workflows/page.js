'use client';
import { useEffect, useState } from 'react';
import { api, fmt } from '../../../lib/api';
import { PageHeader, Field, Empty, Badge } from '../../../components/ui';

const empty = { name: '', actionType: 'notification', message: '', recipient: '', url: '' };

export default function Workflows() {
  const [list, setList] = useState(null);
  const [f, setF] = useState(empty);
  const [err, setErr] = useState('');
  const load = () => api('/workflows').then((d) => setList(d.workflows)).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, []);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function create(e) {
    e.preventDefault(); setErr('');
    const config = f.actionType === 'webhook' ? { url: f.url } : f.actionType === 'notification' ? { recipient: f.recipient, message: f.message } : { message: f.message };
    try { await api('/workflows', { method: 'POST', body: { name: f.name, actionType: f.actionType, config } }); setF(empty); load(); }
    catch (x) { setErr(x.message); }
  }
  const remove = (id) => api(`/workflows/${id}`, { method: 'DELETE' }).then(load).catch((x) => setErr(x.message));

  return (
    <>
      <PageHeader title="Workflows" subtitle="Reusable actions that run when a trigger matches." />
      <form className="card" onSubmit={create}>
        <h3>New workflow</h3>
        <div className="row">
          <Field label="Name" grow={2}><input value={f.name} onChange={set('name')} required minLength={2} /></Field>
          <Field label="Action" grow={1}><select value={f.actionType} onChange={set('actionType')}><option value="notification">Notification</option><option value="log">Log</option><option value="webhook">Webhook</option></select></Field>
        </div>
        <div className="row">
          {f.actionType === 'notification' && <Field label="Recipient" grow={1}><input value={f.recipient} onChange={set('recipient')} required placeholder="sales-team" /></Field>}
          {f.actionType !== 'webhook' && <Field label="Message" grow={2}><input value={f.message} onChange={set('message')} /></Field>}
          {f.actionType === 'webhook' && <Field label="Webhook URL" grow={3}><input type="url" value={f.url} onChange={set('url')} required placeholder="https://example.com/hook" /></Field>}
        </div>
        {err && <p className="err">{err}</p>}
        <button className="btn">Create workflow</button>
      </form>
      <div className="card">
        {!list ? <p className="mute">Loading…</p> : list.length === 0 ? <Empty>No workflows yet.</Empty> : (
          <div className="table-wrap"><table><thead><tr><th>Name</th><th>Action</th><th>Config</th><th>Created</th><th /></tr></thead><tbody>
            {list.map((w) => <tr key={w._id}><td><b>{w.name}</b></td><td><Badge kind="matched">{w.actionType}</Badge></td><td className="mute">{w.config.url || [w.config.recipient, w.config.message].filter(Boolean).join(' — ') || '—'}</td><td>{fmt(w.createdAt)}</td><td><button className="btn ghost sm" onClick={() => confirm('Delete this workflow?') && remove(w._id)}>Delete</button></td></tr>)}
          </tbody></table></div>
        )}
      </div>
    </>
  );
}
