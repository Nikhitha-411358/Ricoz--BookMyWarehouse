import './globals.css';
export const metadata = {
  title: 'RicozTrigger · Event-driven automation platform',
  description: 'Detect business events and trigger automated responses, workflows and actions across connected systems.',
};
export default function RootLayout({ children }) {
  return (<html lang="en"><body>{children}</body></html>);
}
