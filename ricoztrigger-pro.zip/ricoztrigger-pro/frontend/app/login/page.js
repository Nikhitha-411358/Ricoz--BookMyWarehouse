import AuthForm from '../../components/AuthForm';
export const metadata = { title: 'Sign in · RicozTrigger' };
export default function Page() { return <AuthForm mode="login" />; }
