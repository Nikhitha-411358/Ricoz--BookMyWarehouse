import AuthForm from '../../components/AuthForm';
export const metadata = { title: 'Register · RicozTrigger' };
export default function Page() { return <AuthForm mode="register" />; }
