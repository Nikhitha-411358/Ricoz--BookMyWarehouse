import Link from 'next/link';

const steps = ['Event Source', 'Ingestion API', 'Trigger Engine', 'Condition Evaluation', 'Workflow', 'Action', 'Execution Log'];
const features = [
  ['Event source monitoring', 'Ingest business events from any system through a single REST endpoint and detect the conditions that matter.'],
  ['Trigger definition & condition logic', 'Define triggers with nested payload fields and operators: ==, !=, >, <, >=, <= and contains.'],
  ['Automated response & action execution', 'Run workflows that log, notify, or call webhooks across your connected systems — automatically.'],
  ['Performance & reliability monitoring', 'Every run is recorded with status and duration, so failures never go unnoticed.'],
];

export default function Landing() {
  return (
    <div className="landing">
      <header className="topbar">
        <span className="logo">Ricoz<span>Trigger</span></span>
        <nav><a href="#features">Features</a><a href="#how">How it works</a><Link href="/login">Sign in</Link><Link href="/register" className="btn sm">Get started</Link></nav>
      </header>

      <section className="hero">
        <span className="tag">Automation &amp; Workflow</span>
        <h1>Detect business events.<br />Trigger automated responses.</h1>
        <p>RicozTrigger is an enterprise event-driven automation platform for detecting business events and triggering workflows and actions across connected systems.</p>
        <div className="row center-r"><Link href="/register" className="btn lg">Start building</Link><Link href="/login" className="btn ghost lg">Sign in</Link></div>
      </section>

      <section id="features" className="section">
        <h2>Everything you need to automate</h2>
        <div className="grid4">{features.map(([t, d]) => <div className="card" key={t}><h3>{t}</h3><p className="mute">{d}</p></div>)}</div>
      </section>

      <section id="how" className="section alt">
        <h2>How it works</h2>
        <div className="pipeline">{steps.map((s, i) => <div key={s} className="step"><b>{i + 1}</b>{s}</div>)}</div>
        <p className="mute center-t">Example: an <code>ORDER_CREATED</code> event with <code>amount &gt; 50000</code> triggers a sales notification workflow.</p>
      </section>

      <footer className="footer">© {new Date().getFullYear()} RicozTrigger · Next.js · Express · MongoDB</footer>
    </div>
  );
}
