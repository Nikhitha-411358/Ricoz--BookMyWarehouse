export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="page-head">
      <div><h1>{title}</h1>{subtitle && <p className="mute">{subtitle}</p>}</div>
      <div className="row">{children}</div>
    </div>
  );
}
export const Badge = ({ kind, children }) => <span className={`badge b-${kind}`}>{children}</span>;
export const Field = ({ label, children, grow }) => <div className="field" style={grow ? { flex: grow } : undefined}><label>{label}</label>{children}</div>;
export const Empty = ({ children }) => <p className="empty">{children}</p>;
export const StatusBadge = ({ status }) => <Badge kind={status.toLowerCase()}>{status}</Badge>;
