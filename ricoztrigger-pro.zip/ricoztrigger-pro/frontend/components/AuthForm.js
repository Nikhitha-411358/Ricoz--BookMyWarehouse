'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { api } from '../lib/api';
import { Field } from './ui';

export default function AuthForm({ mode }) {
  const router = useRouter();
  const reg = mode === 'register';
  const [f, setF] = useState({ name: '', email: '', password: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault(); setErr(''); setBusy(true);
    try {
      const d = await api(`/auth/${mode}`, { method: 'POST', body: reg ? f : { email: f.email, password: f.password } });
      localStorage.setItem('rt_token', d.token);
      router.replace('/dashboard');
    } catch (x) { setErr(x.message); setBusy(false); }
  }
  return (
    <div className="auth-wrap">
      <form className="card auth" onSubmit={submit}>
        <Link href="/" className="logo">Ricoz<span>Trigger</span></Link>
        <h1>{reg ? 'Create your account' : 'Welcome back'}</h1>
        <p className="mute">{reg ? 'The first account becomes the administrator.' : 'Sign in to manage your automations.'}</p>
        {reg && <Field label="Full name"><input value={f.name} onChange={set('name')} required minLength={2} autoComplete="name" /></Field>}
        <Field label="Email"><input type="email" value={f.email} onChange={set('email')} required autoComplete="email" /></Field>
        <Field label="Password"><input type="password" value={f.password} onChange={set('password')} required minLength={reg ? 8 : 1} autoComplete={reg ? 'new-password' : 'current-password'} /></Field>
        {err && <p className="err">{err}</p>}
        <button className="btn block" disabled={busy}>{busy ? 'Please wait…' : reg ? 'Create account' : 'Sign in'}</button>
        <p className="mute center-t"><Link href={reg ? '/login' : '/register'}>{reg ? 'Already have an account? Sign in' : 'New to RicozTrigger? Create an account'}</Link></p>
      </form>
    </div>
  );
}
