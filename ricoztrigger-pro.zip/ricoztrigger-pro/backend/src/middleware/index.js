const jwt = require('jsonwebtoken');
const { User } = require('../models');

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
exports.HttpError = HttpError;
exports.wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

exports.protect = async (req, _res, next) => {
  try {
    const h = req.headers.authorization || '';
    if (!h.startsWith('Bearer ')) throw new HttpError(401, 'Authentication required');
    const { id } = jwt.verify(h.slice(7), process.env.JWT_SECRET);
    const user = await User.findById(id);
    if (!user) throw new HttpError(401, 'Account no longer exists');
    req.user = user;
    req.scope = user.role === 'admin' ? {} : { owner: user._id }; // admins see everything
    next();
  } catch (e) { next(e instanceof HttpError ? e : new HttpError(401, 'Invalid or expired session')); }
};

exports.validate = (schema) => (req, _res, next) => {
  const r = schema.safeParse(req.body);
  if (!r.success) return next(new HttpError(400, r.error.issues.map((i) => `${i.path.join('.') || 'body'}: ${i.message}`).join('; ')));
  req.body = r.data; next();
};

exports.notFound = (req, _res, next) => next(new HttpError(404, `Route not found: ${req.originalUrl}`));
exports.errorHandler = (err, _req, res, _next) => {
  let status = err.status || 500, message = err.message;
  if (err.name === 'CastError') { status = 400; message = 'Invalid id'; }
  if (err.code === 11000) { status = 409; message = 'Email already registered'; }
  if (err.type === 'entity.parse.failed') { status = 400; message = 'Malformed JSON body'; }
  if (status >= 500) { console.error(err); message = 'Internal server error'; }
  res.status(status).json({ message });
};
