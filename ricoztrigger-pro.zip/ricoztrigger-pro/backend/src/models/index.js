const { Schema, model } = require('mongoose');
const ref = (name) => ({ type: Schema.Types.ObjectId, ref: name });
const owner = { ...ref('User'), required: true, index: true };

exports.User = model('User', new Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, select: false },
  role: { type: String, enum: ['admin', 'user'], default: 'user' },
}, { timestamps: true }));

exports.Workflow = model('Workflow', new Schema({
  owner, name: { type: String, required: true, trim: true },
  actionType: { type: String, enum: ['log', 'notification', 'webhook'], required: true },
  config: { type: Schema.Types.Mixed, default: {} },
}, { timestamps: true }));

exports.Trigger = model('Trigger', new Schema({
  owner, name: { type: String, required: true, trim: true },
  eventType: { type: String, required: true, trim: true, index: true },
  field: { type: String, required: true, trim: true },
  operator: { type: String, enum: ['==', '!=', '>', '<', '>=', '<=', 'contains'], required: true },
  value: { type: String, required: true },
  workflow: ref('Workflow'),
  enabled: { type: Boolean, default: true },
  runs: { type: Number, default: 0 },
  lastRunAt: Date,
}, { timestamps: true }));

exports.Event = model('Event', new Schema({
  owner, eventType: { type: String, required: true, index: true },
  source: { type: String, default: 'manual' },
  payload: { type: Schema.Types.Mixed, default: {} },
  matched: { type: Number, default: 0 },
}, { timestamps: true }));

exports.Execution = model('Execution', new Schema({
  owner, event: ref('Event'), trigger: ref('Trigger'), triggerName: String,
  workflow: ref('Workflow'), workflowName: String,
  status: { type: String, enum: ['SUCCESS', 'FAILED', 'MATCHED'], required: true },
  message: String, durationMs: Number,
}, { timestamps: true }));
