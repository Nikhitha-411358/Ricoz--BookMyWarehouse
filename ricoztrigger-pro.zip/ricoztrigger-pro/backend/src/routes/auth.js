const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { z } = require('zod');
const { User } = require('../models');
const { HttpError, wrap, validate, protect } = require('../middleware');

const sign = (u) => jwt.sign({ id: u._id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
const pub = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role });

router.post('/register', validate(z.object({
  name: z.string().trim().min(2).max(60),
  email: z.string().trim().email(),
  password: z.string().min(8).max(100),
})), wrap(async (req, res) => {
  const { name, email, password } = req.body;
  if (await User.exists({ email: email.toLowerCase() })) throw new HttpError(409, 'Email already registered');
  const role = (await User.countDocuments()) === 0 ? 'admin' : 'user'; // first user = admin
  const user = await User.create({ name, email, password: await bcrypt.hash(password, 12), role });
  res.status(201).json({ token: sign(user), user: pub(user) });
}));

router.post('/login', validate(z.object({ email: z.string().trim().email(), password: z.string().min(1) })), wrap(async (req, res) => {
  const user = await User.findOne({ email: req.body.email.toLowerCase() }).select('+password');
  if (!user || !(await bcrypt.compare(req.body.password, user.password))) throw new HttpError(401, 'Invalid email or password');
  res.json({ token: sign(user), user: pub(user) });
}));

router.get('/me', protect, (req, res) => res.json({ user: pub(req.user) }));
module.exports = router;
