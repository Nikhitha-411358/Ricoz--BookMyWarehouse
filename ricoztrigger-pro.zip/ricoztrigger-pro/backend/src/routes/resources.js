const router = require('express').Router();
const { z } = require('zod');
const { Workflow, Trigger } = require('../models');
const { OPERATORS } = require('../services/engine');
const { HttpError, wrap, validate, protect } = require('../middleware');

router.use(protect);
const oid = z.string().regex(/^[a-f\d]{24}$/i, 'invalid id');

const workflowSchema = z.object({
  name: z.string().trim().min(2).max(100),
}).and(z.discriminatedUnion('actionType', [
  z.object({ actionType: z.literal('log'), config: z.object({ message: z.string().max(300).default('') }) }),
  z.object({ actionType: z.literal('notification'), config: z.object({ recipient: z.string().trim().min(1).max(100), message: z.string().max(300).default('') }) }),
  z.object({ actionType: z.literal('webhook'), config: z.object({ url: z.string().url().refine((u) => /^https?:\/\//.test(u), 'http(s) only') }) }),
]));

const triggerSchema = z.object({
  name: z.string().trim().min(2).max(100),
  eventType: z.string().trim().min(1).max(100),
  field: z.string().trim().min(1).max(100),
  operator: z.enum(OPERATORS),
  value: z.union([z.string(), z.number(), z.boolean()]).transform(String),
  workflow: oid.optional().or(z.literal('').transform(() => undefined)),
  enabled: z.boolean().optional(),
});

// ---- workflows
router.get('/workflows', wrap(async (req, res) => res.json({ workflows: await Workflow.find(req.scope).sort('-createdAt') })));
router.post('/workflows', validate(workflowSchema), wrap(async (req, res) =>
  res.status(201).json({ workflow: await Workflow.create({ ...req.body, owner: req.user._id }) })));
router.delete('/workflows/:id', wrap(async (req, res) => {
  const w = await Workflow.findOne({ _id: req.params.id, ...req.scope });
  if (!w) throw new HttpError(404, 'Workflow not found');
  if (await Trigger.exists({ workflow: w._id })) throw new HttpError(409, 'Workflow is used by a trigger. Delete or change the trigger first.');
  await w.deleteOne(); res.status(204).end();
}));

// ---- triggers
router.get('/triggers', wrap(async (req, res) =>
  res.json({ triggers: await Trigger.find(req.scope).populate('workflow', 'name actionType').sort('-createdAt') })));
router.post('/triggers', validate(triggerSchema), wrap(async (req, res) => {
  if (req.body.workflow && !(await Workflow.exists({ _id: req.body.workflow, ...req.scope }))) throw new HttpError(400, 'Workflow not found');
  res.status(201).json({ trigger: await Trigger.create({ ...req.body, owner: req.user._id }) });
}));
router.patch('/triggers/:id/toggle', wrap(async (req, res) => {
  const t = await Trigger.findOne({ _id: req.params.id, ...req.scope });
  if (!t) throw new HttpError(404, 'Trigger not found');
  t.enabled = !t.enabled; await t.save(); res.json({ trigger: t });
}));
router.delete('/triggers/:id', wrap(async (req, res) => {
  const r = await Trigger.deleteOne({ _id: req.params.id, ...req.scope });
  if (!r.deletedCount) throw new HttpError(404, 'Trigger not found');
  res.status(204).end();
}));
module.exports = router;
