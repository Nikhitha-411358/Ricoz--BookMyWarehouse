const router = require('express').Router();
const { z } = require('zod');
const { Event, Execution, Trigger, Workflow } = require('../models');
const { processEvent } = require('../services/engine');
const { wrap, validate, protect } = require('../middleware');

router.use(protect);
const eventSchema = z.object({
  eventType: z.string().trim().min(1).max(100),
  source: z.string().trim().max(100).default('manual'),
  payload: z.record(z.any()).default({}),
});

router.post('/events', validate(eventSchema), wrap(async (req, res) =>
  res.status(201).json(await processEvent(req.user, req.body))));
router.get('/events', wrap(async (req, res) => res.json({ events: await Event.find(req.scope).sort('-createdAt').limit(50) })));
router.get('/executions', wrap(async (req, res) => res.json({ executions: await Execution.find(req.scope).sort('-createdAt').limit(100) })));

router.get('/stats', wrap(async (req, res) => {
  const s = req.scope;
  const [triggers, activeTriggers, workflows, events, success, failed, recent] = await Promise.all([
    Trigger.countDocuments(s), Trigger.countDocuments({ ...s, enabled: true }), Workflow.countDocuments(s), Event.countDocuments(s),
    Execution.countDocuments({ ...s, status: 'SUCCESS' }), Execution.countDocuments({ ...s, status: 'FAILED' }),
    Execution.find(s).sort('-createdAt').limit(6),
  ]);
  const total = success + failed;
  res.json({ triggers, activeTriggers, workflows, events, executions: total, failed, successRate: total ? Math.round((success / total) * 100) : null, recent });
}));

// One-click demo: workflow + trigger "ORDER_CREATED amount > 50000"
router.post('/demo', wrap(async (req, res) => {
  const owner = req.user._id;
  const workflow = (await Workflow.findOne({ owner, name: 'High Value Order Workflow' })) ||
    (await Workflow.create({ owner, name: 'High Value Order Workflow', actionType: 'notification', config: { recipient: 'sales-team', message: 'High value order detected.' } }));
  if (!(await Trigger.exists({ owner, name: 'High Value Order Trigger' }))) {
    await Trigger.create({ owner, name: 'High Value Order Trigger', eventType: 'ORDER_CREATED', field: 'amount', operator: '>', value: '50000', workflow: workflow._id });
  }
  res.status(201).json({ ok: true });
}));
module.exports = router;
