const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const { notFound, errorHandler } = require('./middleware');

const app = express();
app.use(helmet());
app.use(cors({ origin: (process.env.CLIENT_ORIGIN || 'http://localhost:3000').split(',') }));
app.use(express.json({ limit: '100kb' }));
app.use(morgan('dev'));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, max: 100, standardHeaders: true, legacyHeaders: false }));

app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'RicozTrigger' }));
app.use('/api/auth', require('./routes/auth'));
app.use('/api', require('./routes/resources'));
app.use('/api', require('./routes/events'));
app.use(notFound);
app.use(errorHandler);
module.exports = app;
