require('dotenv').config();
const mongoose = require('mongoose');
const app = require('./app');

const { MONGO_URI, JWT_SECRET, PORT = 5000 } = process.env;
if (!MONGO_URI || !JWT_SECRET) { console.error('Missing MONGO_URI or JWT_SECRET in backend/.env'); process.exit(1); }

mongoose.connect(MONGO_URI, { serverSelectionTimeoutMS: 5000 })
  .then(() => app.listen(PORT, () => console.log(`MongoDB connected - API running on http://localhost:${PORT}`)))
  .catch((e) => { console.error('MongoDB connection failed:', e.message, '\nIs MongoDB running? (docker compose up -d)'); process.exit(1); });
