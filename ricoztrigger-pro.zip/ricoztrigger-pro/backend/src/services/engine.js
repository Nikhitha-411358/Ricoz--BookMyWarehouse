const { Trigger, Event, Execution, Workflow } = require('../models');

const OPERATORS = ['==', '!=', '>', '<', '>=', '<=', 'contains'];
const get = (o, p) => p.split('.').reduce((a, k) => (a !== null && typeof a === 'object' ? a[k] : undefined), o);
const num = (v) => (typeof v === 'boolean' || v === null || String(v).trim() === '' || Number.isNaN(Number(v)) ? null : Number(v));

// Numeric comparison is tried first, so "9" > "10" is handled correctly (a string compare would not).
function compare(actual, op, expected) {
  if (actual === undefined || actual === null) return op === '!=';
  if (op === 'contains') return String(actual).toLowerCase().includes(String(expected).toLowerCase());
  const a = num(actual), e = num(expected);
  if (op === '==' || op === '!=') {
    const eq = a !== null && e !== null ? a === e : String(actual).toLowerCase() === String(expected).toLowerCase();
    return op === '==' ? eq : !eq;
  }
  if (a === null || e === null) return false;
  return { '>': a > e, '<': a < e, '>=': a >= e, '<=': a <= e }[op];
}

const PRIVATE_HOST = /^(localhost|0\.|10\.|127\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|\[?::1\]?$)/i;

async function runWorkflow(wf, ctx) {
  const c = wf.config || {};
  if (wf.actionType === 'log') {
    console.log(`[workflow:${wf.name}]`, c.message || 'executed');
    return { ok: true, message: `LOG: ${c.message || 'Workflow executed successfully.'}` };
  }
  if (wf.actionType === 'notification') {
    return { ok: true, message: `NOTIFICATION to ${c.recipient || 'admin'}: ${c.message || 'RicozTrigger notification'}` };
  }
  if (wf.actionType === 'webhook') {
    const url = new URL(c.url);
    if (process.env.ALLOW_PRIVATE_WEBHOOKS !== 'true' && PRIVATE_HOST.test(url.hostname)) {
      return { ok: false, message: 'WEBHOOK blocked: private/local address (set ALLOW_PRIVATE_WEBHOOKS=true for dev)' };
    }
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 5000);
    try {
      const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(ctx), signal: ctl.signal });
      return { ok: res.ok, message: `WEBHOOK POST ${url.origin}${url.pathname} -> HTTP ${res.status}` };
    } catch (e) {
      return { ok: false, message: `WEBHOOK failed: ${e.name === 'AbortError' ? 'timed out after 5s' : e.message}` };
    } finally { clearTimeout(timer); }
  }
  return { ok: false, message: `Unsupported action type: ${wf.actionType}` };
}

async function processEvent(user, { eventType, source, payload }) {
  const event = await Event.create({ owner: user._id, eventType, source, payload });
  const triggers = await Trigger.find({ owner: user._id, enabled: true, eventType });
  const hits = triggers.filter((t) => compare(get(payload, t.field), t.operator, t.value));

  const executions = [];
  for (const t of hits) {
    const started = Date.now();
    const base = { owner: user._id, event: event._id, trigger: t._id, triggerName: t.name };
    let result, wf = t.workflow ? await Workflow.findById(t.workflow) : null;
    if (!t.workflow) result = { status: 'MATCHED', message: 'Trigger matched; no workflow configured.' };
    else if (!wf) result = { status: 'FAILED', message: 'Workflow not found.' };
    else {
      const r = await runWorkflow(wf, { trigger: t.name, eventType, source, payload, firedAt: new Date() });
      result = { status: r.ok ? 'SUCCESS' : 'FAILED', message: r.message };
    }
    executions.push(await Execution.create({
      ...base, ...result, workflow: wf?._id, workflowName: wf?.name, durationMs: Date.now() - started,
    }));
    await Trigger.updateOne({ _id: t._id }, { $inc: { runs: 1 }, $set: { lastRunAt: new Date() } });
  }
  event.matched = hits.length;
  await event.save();
  return { event, executions };
}

module.exports = { OPERATORS, compare, processEvent };
